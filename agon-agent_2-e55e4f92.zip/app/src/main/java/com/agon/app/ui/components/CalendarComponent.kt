package com.agon.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun CalendarView(
    currentMonth: YearMonth,
    onMonthChange: (YearMonth) -> Unit,
    logStatusForDate: (LocalDate) -> DayStatus,
    onSingleTap: (LocalDate) -> Unit,
    onDoubleTap: (LocalDate) -> Unit,
    onLongPress: (LocalDate) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { onMonthChange(currentMonth.minusMonths(1)) }) {
                Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
            }
            Text(
                text = "${currentMonth.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${currentMonth.year}",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { onMonthChange(currentMonth.plusMonths(1)) }) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Days of week
        Row(modifier = Modifier.fillMaxWidth()) {
            val daysOfWeek = listOf(
                DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY,
                DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY
            )
            for (day in daysOfWeek) {
                Text(
                    text = day.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(3),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Calendar Grid
        val daysInMonth = currentMonth.lengthOfMonth()
        val firstDayOfMonth = currentMonth.atDay(1).dayOfWeek.value // Monday = 1, Sunday = 7
        
        var currentDay = 1
        var rowCount = 0
        
        while (currentDay <= daysInMonth) {
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                for (col in 1..7) {
                    if (rowCount == 0 && col < firstDayOfMonth) {
                        Box(modifier = Modifier.weight(1f))
                    } else if (currentDay > daysInMonth) {
                        Box(modifier = Modifier.weight(1f))
                    } else {
                        val date = currentMonth.atDay(currentDay)
                        val status = logStatusForDate(date)
                        CalendarDay(
                            date = date,
                            status = status,
                            onSingleTap = { onSingleTap(date) },
                            onDoubleTap = { onDoubleTap(date) },
                            onLongPress = { onLongPress(date) },
                            modifier = Modifier.weight(1f)
                        )
                        currentDay++
                    }
                }
            }
            rowCount++
        }
    }
}

enum class DayStatus {
    NONE, LOGGED, SKIPPED, EDITED
}

@Composable
fun CalendarDay(
    date: LocalDate,
    status: DayStatus,
    onSingleTap: () -> Unit,
    onDoubleTap: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val backgroundColor = when (status) {
        DayStatus.LOGGED -> Color(0xFF4CAF50) // Green
        DayStatus.SKIPPED -> Color(0xFFF44336) // Red
        DayStatus.EDITED -> Color(0xFFFF9800) // Orange
        DayStatus.NONE -> Color.Transparent
    }
    val contentColor = if (status != DayStatus.NONE) Color.White else MaterialTheme.colorScheme.onSurface

    val today = LocalDate.now()
    val isToday = date == today

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .padding(2.dp)
            .clip(CircleShape)
            .background(backgroundColor)
            .border(
                width = if (isToday) 2.dp else 0.dp,
                color = if (isToday && status == DayStatus.NONE) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = CircleShape
            )
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onSingleTap() },
                    onDoubleTap = { onDoubleTap() },
                    onLongPress = { onLongPress() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = date.dayOfMonth.toString(),
            color = contentColor,
            fontWeight = if (isToday || status != DayStatus.NONE) FontWeight.Bold else FontWeight.Normal,
            fontSize = 16.sp
        )
    }
}