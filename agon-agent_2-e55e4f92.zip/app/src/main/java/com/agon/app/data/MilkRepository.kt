package com.agon.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.Serializable

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "milk_prefs")

@Serializable
data class MilkLog(
    val dateStr: String,
    val quantityLiters: Float,
    val isSkipped: Boolean = false,
    val isEdited: Boolean = false
)

class MilkRepository(private val context: Context) {
    private val LOGS_KEY = stringPreferencesKey("milk_logs")
    private val PRESET_QTY_KEY = floatPreferencesKey("preset_qty")

    val logsFlow: Flow<Map<String, MilkLog>> = context.dataStore.data.map { prefs ->
        val jsonStr = prefs[LOGS_KEY] ?: "{}"
        try {
            Json.decodeFromString<Map<String, MilkLog>>(jsonStr)
        } catch (e: Exception) {
            emptyMap()
        }
    }

    val presetQtyFlow: Flow<Float> = context.dataStore.data.map { prefs ->
        prefs[PRESET_QTY_KEY] ?: 1.0f
    }

    suspend fun saveLog(log: MilkLog) {
        context.dataStore.edit { prefs ->
            val jsonStr = prefs[LOGS_KEY] ?: "{}"
            val currentMap = try {
                Json.decodeFromString<Map<String, MilkLog>>(jsonStr).toMutableMap()
            } catch (e: Exception) {
                mutableMapOf()
            }
            currentMap[log.dateStr] = log
            prefs[LOGS_KEY] = Json.encodeToString(currentMap)
        }
    }

    suspend fun removeLog(dateStr: String) {
        context.dataStore.edit { prefs ->
            val jsonStr = prefs[LOGS_KEY] ?: "{}"
            val currentMap = try {
                Json.decodeFromString<Map<String, MilkLog>>(jsonStr).toMutableMap()
            } catch (e: Exception) {
                mutableMapOf()
            }
            currentMap.remove(dateStr)
            prefs[LOGS_KEY] = Json.encodeToString(currentMap)
        }
    }

    suspend fun updatePresetQty(qty: Float) {
        context.dataStore.edit { prefs ->
            prefs[PRESET_QTY_KEY] = qty
        }
    }
}