package com.agon.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.data.MilkLog
import com.agon.app.data.MilkRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class MilkViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MilkRepository(application)

    val logs: StateFlow<Map<String, MilkLog>> = repository.logsFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyMap()
    )

    val presetQty: StateFlow<Float> = repository.presetQtyFlow.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        1.0f
    )

    fun toggleLog(date: LocalDate) {
        val dateStr = date.toString()
        val currentLogs = logs.value
        val existingLog = currentLogs[dateStr]

        viewModelScope.launch {
            if (existingLog == null) {
                repository.saveLog(MilkLog(dateStr, presetQty.value, isSkipped = false, isEdited = false))
            } else if (!existingLog.isSkipped) {
                repository.removeLog(dateStr)
            } else {
                repository.saveLog(MilkLog(dateStr, presetQty.value, isSkipped = false, isEdited = false))
            }
        }
    }

    fun markSkipped(date: LocalDate) {
        val dateStr = date.toString()
        val currentLogs = logs.value
        val existingLog = currentLogs[dateStr]
        
        viewModelScope.launch {
            if (existingLog?.isSkipped == true) {
                repository.removeLog(dateStr)
            } else {
                repository.saveLog(MilkLog(dateStr, 0f, isSkipped = true, isEdited = false))
            }
        }
    }

    fun updateManualLog(date: LocalDate, qty: Float) {
        val dateStr = date.toString()
        viewModelScope.launch {
            repository.saveLog(MilkLog(dateStr, qty, isSkipped = false, isEdited = true))
        }
    }

    fun updatePresetQty(qty: Float) {
        viewModelScope.launch {
            repository.updatePresetQty(qty)
        }
    }
}