package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

val Blue40 = Color(0xFF1976D2)
val LightBlue40 = Color(0xFF03A9F4)
val Green40 = Color(0xFF388E3C)
val Red40 = Color(0xFFD32F2F)

val Blue80 = Color(0xFF90CAF9)
val LightBlue80 = Color(0xFF81D4FA)
val Green80 = Color(0xFFA5D6A7)
val Red80 = Color(0xFFEF9A9A)

