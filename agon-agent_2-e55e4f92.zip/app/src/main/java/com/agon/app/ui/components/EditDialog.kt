package com.agon.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun EditQuantityDialog(
    date: LocalDate,
    initialQty: Float,
    onDismiss: () -> Unit,
    onSave: (Float) -> Unit
) {
    var qtyStr by remember { mutableStateOf(initialQty.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Milk Quantity") },
        text = {
            Column {
                Text(
                    text = "Date: ${date.month.getDisplayName(TextStyle.SHORT, Locale.getDefault())} ${date.dayOfMonth}, ${date.year}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = qtyStr,
                    onValueChange = { qtyStr = it },
                    label = { Text("Quantity (Liters)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val qty = qtyStr.toFloatOrNull()
                if (qty != null && qty >= 0) {
                    onSave(qty)
                }
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}