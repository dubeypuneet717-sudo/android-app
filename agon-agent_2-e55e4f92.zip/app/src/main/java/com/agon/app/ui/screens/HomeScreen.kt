package com.agon.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.agon.app.ui.components.CalendarView
import com.agon.app.ui.components.DashboardCard
import com.agon.app.ui.components.DayStatus
import com.agon.app.ui.components.EditQuantityDialog
import com.agon.app.viewmodel.MilkViewModel
import java.time.LocalDate
import java.time.YearMonth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: MilkViewModel = viewModel()) {
    val logs by viewModel.logs.collectAsState()
    val presetQty by viewModel.presetQty.collectAsState()
    
    var currentMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDateForEdit by remember { mutableStateOf<LocalDate?>(null) }

    val totalLiters = remember(logs, currentMonth) {
        logs.values.filter { 
            val date = LocalDate.parse(it.dateStr)
            YearMonth.from(date) == currentMonth && !it.isSkipped
        }.sumOf { it.quantityLiters.toDouble() }.toFloat()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Milk Tracker") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            DashboardCard(totalLiters = totalLiters, presetQty = presetQty)
            
            CalendarView(
                currentMonth = currentMonth,
                onMonthChange = { currentMonth = it },
                logStatusForDate = { date ->
                    val log = logs[date.toString()]
                    when {
                        log == null -> DayStatus.NONE
                        log.isSkipped -> DayStatus.SKIPPED
                        log.isEdited -> DayStatus.EDITED
                        else -> DayStatus.LOGGED
                    }
                },
                onSingleTap = { date -> viewModel.toggleLog(date) },
                onDoubleTap = { date -> viewModel.markSkipped(date) },
                onLongPress = { date -> selectedDateForEdit = date }
            )
        }
    }

    selectedDateForEdit?.let { date ->
        val log = logs[date.toString()]
        val initialQty = log?.quantityLiters ?: presetQty
        EditQuantityDialog(
            date = date,
            initialQty = initialQty,
            onDismiss = { selectedDateForEdit = null },
            onSave = { newQty ->
                viewModel.updateManualLog(date, newQty)
                selectedDateForEdit = null
            }
        )
    }
}